# python-packages
This is a repository for Python packages.

2019-08-05   
repo created  

2019-08-05   
package distribution tutorials
(Windows 10, Anaconda3 Powershell Prompt logs)  
https://github.com/Nov05/Lambda-School-Data-Science/blob/master/miscellaneous/2019-08-05%20distribute%20python%20packages.md


