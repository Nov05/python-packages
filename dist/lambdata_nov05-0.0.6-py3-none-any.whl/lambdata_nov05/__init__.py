name = "Technically the name is an attribute of the package object, so it can be anything as long as Python allows."

import pandas as pd